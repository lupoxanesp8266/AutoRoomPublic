package lupoxan.autoroom.com.autoroom11;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

/**
 * @author lupo.xan
 * @version 0.1.8
 * @since 02/06/2019
 */
public class Graficas extends AppCompatActivity {

    LineChart chart;
    Spinner spinner;

    ArrayList<String> dates = new ArrayList<>();
    ArrayList<String> xAxes = new ArrayList<>();

    ArrayList<Entry> yAxesExt = new ArrayList<>();
    ArrayList<Entry> yAxesInt = new ArrayList<>();

    LineDataSet dataSet;
    LineDataSet dataSetInt;

    ArrayAdapter<String> adapter;

    ImageButton today;

    private static Calendar cal;
    private MyFirebase firebase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graficas);

        spinner = findViewById(R.id.spinner2);
        chart = findViewById(R.id.graph);
        today = findViewById(R.id.today_button);

        firebase = new MyFirebase();

        adapter = new ArrayAdapter<>(Graficas.this, R.layout.datolayout, R.id.datosSensors, dates);
        spinner.setAdapter(adapter);
        //Rellenamos el spinner con las dates actuales
        firebase.getDb().child("sensores").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                dates.clear();
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    dates.add(ds.getKey());
                }

                dates.remove("movimiento");
                dates.remove("temp_ext");
                dates.remove("temp_int");
                dates.remove("PIR");

                adapter.notifyDataSetChanged();

                cal = Calendar.getInstance();

                spinner.setSelection(adapter.getPosition(String.format("%02d-%02d-%04d", cal.get(Calendar.DATE), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.YEAR))));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        //Cuando notemos un cambio de seleccion en el spinner, cambiamos los valores de la grafica
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(Graficas.this, (String) parent.getItemAtPosition(position), Toast.LENGTH_SHORT).show();
                generarGrafica();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        today.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
                Date fecha = new Date();
                //spinner.getItemAtPosition(adapter.getPosition(format.format(fecha)));
                spinner.setSelection(adapter.getPosition(format.format(fecha)));
                Toast.makeText(getApplicationContext(), format.format(fecha), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void generarGrafica() {
        firebase.getDb().child("sensores").child((String) spinner.getSelectedItem()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //Limpiamos los dataSets para no repetir los valores
                xAxes.clear();
                yAxesExt.clear();
                yAxesInt.clear();

                for (DataSnapshot ds : dataSnapshot.getChildren()) {

                    String tempe = (String) dataSnapshot.child(ds.getKey()).child("Temp_Ext").getValue();
                    String tempi = (String) dataSnapshot.child(ds.getKey()).child("Temp_Int").getValue();

                    if (tempe == null || tempe.equals("NaN ºC") || tempe.equals("")) {
                        tempe = "0,0 ºC";
                    }

                    if (tempi == null || tempi.equals("NaN ºC") || tempi.equals("")) {
                        tempi = "0,0 ºC";
                    }

                    //Cortar la cadena para quitar ºC
                    String[] tempis = tempi.replaceAll(",",".").trim().split("ºC");
                    String[] tempes = tempe.replaceAll(",",".").trim().split("ºC");
                    String[] hora = ds.getKey().split(":");
                    //Añadir los valores a los datasets
                    xAxes.add(hora[0]+ ":" + hora[1]);//Añadiendo las horas
                    yAxesExt.add(new Entry(Float.parseFloat(tempes[0]), xAxes.size()));
                    yAxesInt.add(new Entry(Float.parseFloat(tempis[0]), xAxes.size()));
                }//*/

                dataSet = new LineDataSet(yAxesExt, getResources().getString(R.string.tempExt));
                dataSetInt = new LineDataSet(yAxesInt, getResources().getString(R.string.tempInt));

                dataSet.setDrawCircles(true);
                dataSet.setDrawFilled(true);
                dataSet.setColor(Color.BLUE);
                dataSet.setCircleColor(Color.BLUE);
                dataSet.setFillColor(Color.BLUE);

                dataSetInt.setDrawCircles(true);
                dataSetInt.setDrawFilled(true);
                dataSetInt.setCircleColor(Color.RED);
                dataSetInt.setColor(Color.RED);
                dataSetInt.setFillColor(Color.RED);

                ArrayList<ILineDataSet> lineDataSet = new ArrayList<>();//Crear uno nuevo para no repetir las leyendas

                lineDataSet.add(dataSet);//Añadimos los valores de la temperatura exterior
                lineDataSet.add(dataSetInt);//Añadimos los valores de la temperatura interios

                chart.setData(new LineData(xAxes, lineDataSet));//Añadimos esos valores al gráfico

                chart.setVisibleXRangeMaximum(49);

                chart.setDescription(getResources().getString(R.string.temperatures));
                chart.setDescriptionColor(Color.BLACK);

                chart.setTouchEnabled(true);
                chart.setDragEnabled(true);
                chart.setEnabled(true);
                chart.postInvalidate();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.graphmenu, menu);
        return true;
    }

    @Override
    public void onBackPressed() {
        finish();
        overridePendingTransition(R.anim.zoom_fade_in, R.anim.zoom_fade_out);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                overridePendingTransition(R.anim.zoom_fade_in, R.anim.zoom_fade_out);
                return true;
            case R.id.registros:
                intent = new Intent(getApplicationContext(), IntruderActivity.class);
                intent.putExtra("fecha", (String) spinner.getSelectedItem());
                startActivity(intent);
                overridePendingTransition(R.anim.splash_in, R.anim.splash_out);
                return true;
            case R.id.cambio:
                intent = new Intent(getApplicationContext(), ListaValores.class);
                intent.putExtra("fecha", (String) spinner.getSelectedItem());
                startActivity(intent);
                overridePendingTransition(R.anim.splash_in, R.anim.splash_out);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
