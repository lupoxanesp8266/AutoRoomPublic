package lupoxan.autoroom.com.autoroom11;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.util.Log;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Random;

/**
 * @author lupo.xan
 * @version 0.2.2
 * @since 10/04/2019
 */
public class MessagingService extends FirebaseMessagingService {
    long[] vibrate = {0, 500, 10, 500, 10};

    private final String TEMPSCHANNELID = "com.lupoxan.autoRoom.temps";
    private final String MOVESCHANNELID = "com.lupoxan.autoRoom.movement";

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);

        try {
            showNotificacion(remoteMessage.getNotification().getTitle(), remoteMessage.getNotification().getBody());
        } catch (IllegalArgumentException e) {
            Log.d("channel", e.getMessage());
        }
    }

    public void showNotificacion(String title, String body) {
        //Create the channel TEMPS
        NotificationChannel temps = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            temps = new NotificationChannel(TEMPSCHANNELID, "Temps", NotificationManager.IMPORTANCE_HIGH);
            //Configure the channel´s initial settings
            temps.setName("Temperaturas");
            temps.setShowBadge(true);
            temps.setSound(temps.getSound(),temps.getAudioAttributes());
            temps.setVibrationPattern(vibrate);
            temps.enableVibration(true);

            //Submit the notification channel object to the notification manager
            NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.createNotificationChannel(temps);
            //Create a notification
            Notification notification = new Notification.Builder(this)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setSmallIcon(android.R.drawable.star_off)
                    .setShowWhen(true)
                    .setAutoCancel(true)
                    .setChannelId(TEMPSCHANNELID)
                    .build();

            notificationManager.notify(new Random().nextInt(), notification);
        }else{
            //Do nothing for now
            Log.d("Not_for_23","Message arrives");
        }




    }


    @Override
    public void onNewToken(String s) {
        super.onNewToken(s);
    }


}
